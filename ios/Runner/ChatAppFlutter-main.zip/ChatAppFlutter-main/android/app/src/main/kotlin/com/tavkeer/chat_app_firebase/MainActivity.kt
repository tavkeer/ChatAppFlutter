package com.tavkeer.chat_app_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
